from mflux.callbacks.callback_manager import CallbackManager
from mflux.cli.parser.parsers import CommandLineParser, lora_init_kwargs_from_args
from mflux.models.common.resolution.config_resolution import ConfigResolution
from mflux.models.ernie_image.latent_creator import ErnieLatentCreator
from mflux.models.ernie_image.variants.txt2img.ernie_image import ErnieImage
from mflux.utils.dimension_resolver import DimensionResolver
from mflux.utils.exceptions import PromptFileReadError, StopImageGenerationException
from mflux.utils.prompt_util import PromptUtil

IGNORED_OPTIONS = {
    "--negative-prompt": "turbo pins guidance to 1.0, so there is no unconditional pass for a negative prompt to steer.",
}

CONDITIONAL_OPTIONS = {
    "--guidance": {
        "condition": "must be 1.0",
        "reason": "turbo is guidance-distilled; any other value exits with an error.",
    },
}


def build_parser() -> CommandLineParser:
    parser = CommandLineParser(
        description="Generate an image using ERNIE-Image-Turbo (distilled, 8 steps) based on a prompt."
    )
    parser.add_general_arguments()
    parser.add_model_arguments(require_model_arg=False)
    parser.add_lora_arguments()
    parser.add_image_generator_arguments(supports_metadata_config=True, supports_dimension_scale_factor=True)
    parser.add_image_to_image_arguments(required=False)
    parser.add_pid_decode_arguments()
    parser.add_output_arguments()
    parser.set_defaults(model="ernie-image-turbo")
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    CommandLineParser.warn_ignored_options(IGNORED_OPTIONS)

    if args.guidance is None:
        args.guidance = 1.0
    if args.guidance != 1.0:
        parser.error("--guidance is only supported for base ERNIE-Image. Use --guidance 1.0 for turbo.")

    # --model accepts only ernie-image-turbo aliases; base ernie-image has its own CLI
    # and anything else errors instead of being silently run as ERNIE-Image-Turbo.
    model = ErnieImage(
        model_config=ConfigResolution.resolve_restricted(args.model, "ernie-image-turbo", model_path=args.model_path),
        quantize=args.quantize,
        model_path=args.model_path,
        **lora_init_kwargs_from_args(args),
    )

    memory_saver = CallbackManager.register_callbacks(
        args=args,
        model=model,
        latent_creator=ErnieLatentCreator,
    )

    try:
        width, height = DimensionResolver.resolve(
            width=args.width,
            height=args.height,
            reference_image_path=args.image_path,
        )

        for seed in args.seed:
            image = model.generate_image(
                seed=seed,
                prompt=PromptUtil.read_prompt(args),
                width=width,
                height=height,
                guidance=args.guidance,
                image_path=args.image_path,
                num_inference_steps=args.steps,
                image_strength=args.image_strength,
                scheduler=args.scheduler,
                negative_prompt=args.negative_prompt,
                pid_decode=args.pid_decode,
                pid_degrade_sigma=args.pid_degrade_sigma,
            )
            image.save(path=args.output.format(seed=seed), export_json_metadata=args.metadata)
    except (StopImageGenerationException, PromptFileReadError) as exc:
        print(exc)
    finally:
        if memory_saver:
            print(memory_saver.memory_stats())


if __name__ == "__main__":
    main()
