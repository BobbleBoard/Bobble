from functools import partial
from typing import Optional, Tuple

import mlx.core as mx
import mlx.nn as nn


@partial(mx.compile, shapeless=True)
def compute_g(A_log, a, dt_bias):
    return mx.exp(-mx.exp(A_log.astype(mx.float32)) * nn.softplus(a + dt_bias))


@partial(mx.compile, shapeless=True)
def compute_g_safe(A_log, a, dt_bias, lower_bound):
    return mx.exp(
        lower_bound * mx.sigmoid(mx.exp(A_log.astype(mx.float32)) * (a + dt_bias))
    )


def _make_gated_delta_kernel(
    has_mask=False,
    vectorized=False,
    capture_states=False,
):
    if not mx.metal.is_available():
        return None
    mask_source = "mask[b_idx * T + t]" if has_mask else "true"

    # Configure g indexing based on whether gating is vectorized
    if vectorized:
        g_comment = "// g: [B, T, Hv, Dk]"
        g_setup = "auto g_ = g + (b_idx * T * Hv + hv_idx) * Dk;"
        g_access = "g_[s_idx]"
        g_advance = "g_ += Hv * Dk;"
    else:
        g_comment = "// g: [B, T, Hv]"
        g_setup = "auto g_ = g + b_idx * T * Hv;"
        g_access = "g_[hv_idx]"
        g_advance = "g_ += Hv;"

    states_setup = (
        "auto states_ = states + "
        "((b_idx * StateT * Hv + hv_idx) * Dv + dv_idx) * Dk;"
        if capture_states
        else ""
    )
    states_store = (
        """
          if (t < StateT) {
            for (int i = 0; i < n_per_t; ++i) {
              auto s_idx = n_per_t * dk_idx + i;
              states_[s_idx] = static_cast<StT>(state[i]);
            }
          }
        """
        if capture_states
        else ""
    )
    states_advance = (
        "if (t < StateT) { states_ += Hv * Dv * Dk; }" if capture_states else ""
    )

    source = f"""
        auto n = thread_position_in_grid.z;
        auto b_idx = n / Hv;
        auto hv_idx = n % Hv;
        auto hk_idx = hv_idx / (Hv / Hk);
        constexpr int n_per_t = Dk / 32;

        // q, k: [B, T, Hk, Dk]
        auto q_ = q + b_idx * T * Hk * Dk + hk_idx * Dk;
        auto k_ = k + b_idx * T * Hk * Dk + hk_idx * Dk;

        // v, y: [B, T, Hv, Dv]
        auto v_ = v + b_idx * T * Hv * Dv + hv_idx * Dv;
        y += b_idx * T * Hv * Dv + hv_idx * Dv;

        auto dk_idx = thread_position_in_threadgroup.x;
        auto dv_idx = thread_position_in_grid.y;

        // state_in, state_out: [B, Hv, Dv, Dk]
        auto i_state = state_in + (n * Dv + dv_idx) * Dk;
        auto o_state = state_out + (n * Dv + dv_idx) * Dk;
        {states_setup}

        float state[n_per_t];
        for (int i = 0; i < n_per_t; ++i) {{
          auto s_idx = n_per_t * dk_idx + i;
          state[i] = static_cast<float>(i_state[s_idx]);
        }}

        {g_comment}
        {g_setup}
        auto beta_ = beta + b_idx * T * Hv;

        for (int t = 0; t < T; ++t) {{
          if ({mask_source}) {{
            float kv_mem = 0.0f;
            for (int i = 0; i < n_per_t; ++i) {{
              auto s_idx = n_per_t * dk_idx + i;
              state[i] = state[i] * {g_access};
              kv_mem += state[i] * k_[s_idx];
            }}
            kv_mem = simd_sum(kv_mem);

            auto delta = (v_[dv_idx] - kv_mem) * beta_[hv_idx];

            float out = 0.0f;
            for (int i = 0; i < n_per_t; ++i) {{
              auto s_idx = n_per_t * dk_idx + i;
              state[i] = state[i] + k_[s_idx] * delta;
              out += state[i] * q_[s_idx];
            }}
            out = simd_sum(out);
            if (thread_index_in_simdgroup == 0) {{
              y[dv_idx] = static_cast<InT>(out);
            }}
          }} else {{
            y[dv_idx] = static_cast<InT>(0);
          }}
          {states_store}
          // Increment data pointers to next time step
          q_ += Hk * Dk;
          k_ += Hk * Dk;
          v_ += Hv * Dv;
          y += Hv * Dv;
          {g_advance}
          beta_ += Hv;
          {states_advance}
        }}
        for (int i = 0; i < n_per_t; ++i) {{
          auto s_idx = n_per_t * dk_idx + i;
          o_state[s_idx] = static_cast<StT>(state[i]);
        }}
    """
    inputs = ["q", "k", "v", "g", "beta", "state_in", "T"]
    if has_mask:
        inputs.append("mask")

    suffix = ""
    if vectorized:
        suffix += "_vec"
    if has_mask:
        suffix += "_mask"
    if capture_states:
        suffix += "_states"

    return mx.fast.metal_kernel(
        name=f"gated_delta_step{suffix}",
        input_names=inputs,
        output_names=(
            ["y", "state_out", "states"] if capture_states else ["y", "state_out"]
        ),
        source=source,
    )


_gated_delta_kernel = _make_gated_delta_kernel(has_mask=False, vectorized=False)
_gated_delta_kernel_masked = _make_gated_delta_kernel(has_mask=True, vectorized=False)
_gated_delta_kernel_vec = _make_gated_delta_kernel(has_mask=False, vectorized=True)
_gated_delta_kernel_vec_masked = _make_gated_delta_kernel(
    has_mask=True, vectorized=True
)
_gated_delta_kernel_states = _make_gated_delta_kernel(capture_states=True)
_gated_delta_kernel_masked_states = _make_gated_delta_kernel(
    has_mask=True,
    capture_states=True,
)
_gated_delta_kernel_vec_states = _make_gated_delta_kernel(
    vectorized=True,
    capture_states=True,
)
_gated_delta_kernel_vec_masked_states = _make_gated_delta_kernel(
    has_mask=True,
    vectorized=True,
    capture_states=True,
)


@mx.compile
def _gated_delta_step_ops(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    g: mx.array,
    beta: mx.array,
    state: mx.array,
    mask: Optional[mx.array] = None,
) -> Tuple[mx.array, mx.array]:
    """
    Ops-based reference implementation for a single recurrent step.

    Shapes:
      - q, k: [B, H, Dk]
      - v: [B, H, Dv]
      - g: [B, H] or [B, H, Dk]
      - beta: [B, H]
      - state: [B, H, Dv, Dk]
    Returns:
      - y: [B, H, Dv]
      - new_state: [B, H, Dv, Dk]
    """

    # Decay
    old_state = state
    if g.ndim == 2:
        decay = g[..., None, None]
    elif g.ndim == 3:
        decay = g[..., None, :]
    else:
        raise ValueError(f"Unsupported gating shape {g.shape}")
    state = state * decay
    kv_mem = (state * k[..., None, :]).sum(axis=-1)  # [B, H, Dv]
    delta = (v - kv_mem) * beta[..., None]  # [B, H, Dv]
    state = state + k[..., None, :] * delta[..., None]
    # Output projection along key dim with q
    y = (state * q[..., None, :]).sum(axis=-1)  # [B, H, Dv]

    if mask is not None:
        mask = mx.expand_dims(mask, axis=(1, 2, 3))
        state = mx.where(mask, state, old_state)
    return y.astype(q.dtype), state


def gated_delta_kernel(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    g: mx.array,
    beta: mx.array,
    state: mx.array,
    mask: Optional[mx.array] = None,
    state_steps: Optional[int] = None,
) -> Tuple[mx.array, ...]:
    B, T, Hk, Dk = k.shape
    Hv, Dv = v.shape[2:]
    input_type = q.dtype
    state_type = state.dtype
    if g.ndim == 4:
        kernel = (
            _gated_delta_kernel_vec
            if state_steps is None
            else _gated_delta_kernel_vec_states
        )
        inputs = [q, k, v, g, beta, state, T]
        if mask is not None:
            kernel = (
                _gated_delta_kernel_vec_masked
                if state_steps is None
                else _gated_delta_kernel_vec_masked_states
            )
            inputs.append(mask)
    else:
        kernel = (
            _gated_delta_kernel if state_steps is None else _gated_delta_kernel_states
        )
        inputs = [q, k, v, g, beta, state, T]
        if mask is not None:
            kernel = (
                _gated_delta_kernel_masked
                if state_steps is None
                else _gated_delta_kernel_masked_states
            )
            inputs.append(mask)

    template = [
        ("InT", input_type),
        ("StT", state_type),
        ("Dk", Dk),
        ("Dv", Dv),
        ("Hk", Hk),
        ("Hv", Hv),
    ]
    output_shapes = [(B, T, Hv, Dv), state.shape]
    output_dtypes = [input_type, state_type]
    if state_steps is not None:
        template.append(("StateT", state_steps))
        output_shapes.append((B, state_steps, Hv, Dv, Dk))
        output_dtypes.append(state_type)

    return kernel(
        inputs=inputs,
        template=template,
        grid=(32, Dv, B * Hv),
        threadgroup=(32, 4, 1),
        output_shapes=output_shapes,
        output_dtypes=output_dtypes,
    )


def gated_delta_ops(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    g: mx.array,
    beta: mx.array,
    state: Optional[mx.array] = None,
    mask: Optional[mx.array] = None,
    state_steps: Optional[int] = None,
) -> Tuple[mx.array, ...]:
    """
    Ops-based reference implementation for prompt prefill (sequential loop).
    Supports both scalar and vectorized gating.

    Shapes:
      - q, k: [B, T, Hk, Dk]
      - v: [B, T, Hv, Dv]
      - g: [B, T, Hv] (scalar) or [B, T, Hv, Dk] (vectorized)
      - beta: [B, T, Hv]
      - state: [B, Hv, Dv, Dk]
    Returns:
      - y: [B, T, Hv, Dv]
      - state: [B, Hv, Dv, Dk]
    """
    B, T, Hk, Dk = q.shape
    Hv, Dv = v.shape[-2:]
    if state is None:
        state = mx.zeros((B, Hv, Dv, Dk), dtype=mx.float32)

    if (repeat_factor := Hv // Hk) > 1:
        q = mx.repeat(q, repeat_factor, -2)
        k = mx.repeat(k, repeat_factor, -2)

    ys = []
    states = []
    for t in range(T):
        y, state = _gated_delta_step_ops(
            q[:, t],
            k[:, t],
            v[:, t],
            g[:, t],
            beta[:, t],
            state,
            None if mask is None else mask[:, t],
        )
        ys.append(y)
        if state_steps is not None and t < state_steps:
            states.append(state)
    y = mx.stack(ys, axis=1)
    if state_steps is not None:
        return y, state, mx.stack(states, axis=1)
    return y, state


def gated_delta_update(
    q: mx.array,
    k: mx.array,
    v: mx.array,
    a: mx.array,
    b: mx.array,
    A_log: mx.array,
    dt_bias: mx.array,
    state: Optional[mx.array] = None,
    mask: Optional[mx.array] = None,
    use_kernel: bool = True,
    lower_bound: Optional[float] = None,
    state_steps: Optional[int] = None,
    cache=None,
    cache_index: int = 1,
) -> Tuple[mx.array, ...]:
    if cache is not None:
        if state is not None or state_steps is not None:
            raise ValueError("The cache owns recurrent state and history retention.")
        return cache.update_recurrent(
            cache_index,
            q.shape[1],
            lambda initial, steps: gated_delta_update(
                q,
                k,
                v,
                a,
                b,
                A_log,
                dt_bias,
                state=initial,
                mask=mask,
                use_kernel=use_kernel,
                lower_bound=lower_bound,
                state_steps=steps,
            ),
        )
    beta = mx.sigmoid(b)
    if lower_bound is None:
        g = compute_g(A_log, a, dt_bias)
    else:
        g = compute_g_safe(A_log, a, dt_bias, lower_bound)
    if state is None:
        B, _, Hk, Dk = q.shape
        Hv, Dv = v.shape[-2:]
        state = mx.zeros((B, Hv, Dv, Dk), dtype=mx.float32)
    if state_steps is not None and not 0 < state_steps <= q.shape[1]:
        raise ValueError("state_steps must be between one and the sequence length.")

    if (
        not use_kernel
        or mx.default_device() != mx.gpu
        or not mx.metal.is_available()
        or k.shape[-1] < 32
        or k.shape[-1] % 32 != 0
    ):
        return gated_delta_ops(q, k, v, g, beta, state, mask, state_steps)
    return gated_delta_kernel(q, k, v, g, beta, state, mask, state_steps)
